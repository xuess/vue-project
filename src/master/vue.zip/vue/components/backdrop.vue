<template>
    <div id="backdrop" v-show="sel"  @click="close" @touchmove="forbidSlide" >
    </div>
</template>
<script>

    export default {
        name: 'backdrop',
        props:['sel'],
        data:function(){
            return{
                isShow:this.sel
            }
        },
        methods: {
            forbidSlide:function(e){
                e.preventDefault();
                return false;
            },
             close:function(){
                this.isShow=false;
                this.$emit('close',this.isShow);
            }
        }
    }
</script>

<style lang="scss" scoped>
    #backdrop {
        z-index: 1000;
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background-color: #000;
        opacity: 0.6;
    } 
</style>

