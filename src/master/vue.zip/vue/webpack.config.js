const webpack = require('webpack');

module.exports = function() {
	return {
		entry: {
			'vue/js/index': './src/vue/js/index.js'
		},
		module: {
			rules: [{
				test: /\.html$/,
				use: ['file-loader?name=vue/[name].[ext]', 'extract-loader?publicPath=/', {
					loader: 'html-loader',
					options: {
						minimize: true,
						collapseWhitespace: false,
					}
				}]
			}]
		},
		plugins: [
			// new webpack.optimize.CommonsChunkPlugin({
			// 	// The chunk name of the commons chunk.
			// 	name: "vue/js/vendor",
			// 	// The minimum number of chunks which need to contain a module before it's moved into the commons chunk.
			// 	minChunks: function(module, count) {
			// 		var moduleContext = module.context;
			// 		var moduleResource = module.resource;

			// 		console.log("CommonsChunkPlugin:vendor->" + moduleResource + "->" + count);

			// 		if (moduleResource && (/\.(css|scss|less)$/).test(moduleResource)) {
			// 			return false;
			// 		}

			// 		return moduleContext && moduleContext.indexOf('node_modules') !== -1;
			// 	}
			// }),
			new webpack.optimize.CommonsChunkPlugin({
				// The chunk name of the commons chunk.
				name: "vue/js/common",
				// Select the source chunks by chunk names.
				chunks: ["vue/js/index", "vue/js/cheap"],
			}),
			new webpack.optimize.CommonsChunkPlugin({
				// The chunk name of the commons chunk.
				name: "vue/js/manifest",
				// The minimum number of chunks which need to contain a module before it's moved into the commons chunk.
				minChunks: Infinity,
			}),
		],
	};
};