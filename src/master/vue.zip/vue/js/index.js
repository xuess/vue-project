import $ from 'jquery';
import cacheObj from 'LocalCache.js';
// import 'Env.js';
// import {
// 	getUrlParam
// } from 'util.js';

require('../html/index.html');
import goTop from '../components/goTop.vue';

import downloadTipWx from '../components/downloadTipWx.vue';
import backdrop from '../components/backdrop.vue';
    // import backdrop from 'backdrop.vue';

new Vue({
 	el:"#app",
 	components:{
 		downloadTipWx,
 		backdrop,
 		goTop
 	},
 	data:{
 		isShow:true,
 		title:"淘金农场"
 	},
 	methods:{
 		isShowFinal:function(){
 			this.isShow=false;
 		},
 		windowPop:function(){
 			this.isShow=true;
 		}
 	}
 });

/*var template = require('arttemplate.js');

require('swiper.jquery.js');
require('jquery.scrollstop.js');
require('jquery.lazyload.js');
require('swiper.jquery.css');

require('../style/index.scss');
require('../html/index.html');

$(function() {
	var obj = new PageObj();
	obj.init();
});




if (process.env.NODE_ENV === "development") {
	pageData = {
		"configData": {
			"banner": [{
				"imageUrl": "https://img.alicdn.com/imgextra/i1/2296013456/TB2aLb9s3JkpuFjSszcXXXfsFXa_!!2296013456.png",
				"target": "http://mo.m.taobao.com/union/rttoplist?pid=mm_123557025_24602495_1073644"
			}],
			"icon": [{
				"imageUrl": "https://img.alicdn.com/imgextra/i4/2296013456/TB25WhyteJ8puFjy1XbXXagqVXa_!!2296013456.png",
				"target": "https://s.click.taobao.com/bfCaXiw",
				"text": "抢红包"
			}, {
				"imageUrl": "https://img.alicdn.com/imgextra/i3/2296013456/TB2KKUowJBopuFjSZPcXXc9EpXa_!!2296013456.png",
				"target": "https://s.click.taobao.com/0FIbXiw",
				"text": "疯抢榜"
			}, {
				"imageUrl": "https://img.alicdn.com/imgextra/i3/2296013456/TB2mMc_wUlnpuFjSZFjXXXTaVXa_!!2296013456.png",
				"target": "cheap.html",
				"text": "精选9.9"
			}, {
				"imageUrl": "https://img.alicdn.com/imgextra/i2/2296013456/TB2gBJOw9FmpuFjSZFrXXayOXXa_!!2296013456.png",
				"target": "https://s.click.taobao.com/YWWaXiw",
				"text": "超值品牌"
			}],
			"block": [{
				"data": [{
					"imageUrl": "https://img.alicdn.com/imgextra/i1/2296013456/TB2DZVFtmFjpuFjSspbXXXagVXa_!!2296013456.png",
					"target": "https://s.click.taobao.com/M8EVXiw"
				}, {
					"imageUrl": "https://img.alicdn.com/imgextra/i3/2296013456/TB25Thqw5pnpuFjSZFIXXXh2VXa_!!2296013456.png",
					"target": "https://s.click.taobao.com/bjNXXiw"
				}, {
					"imageUrl": "https://img.alicdn.com/imgextra/i3/2296013456/TB2xI.GqNRDOuFjSZFzXXcIipXa_!!2296013456.png",
					"target": "https://s.click.taobao.com/FuMYXiw"
				}],
				"type": "block_12"
			}],
			"category": [{
				"categoryCode": 0,
				"categoryName": "全部"
			}, {
				"categoryCode": 300,
				"categoryName": "女装"
			}, {
				"categoryCode": 370,
				"categoryName": "男装"
			}, {
				"categoryCode": 380,
				"categoryName": "内衣"
			}, {
				"categoryCode": 310,
				"categoryName": "美妆"
			}, {
				"categoryCode": 320,
				"categoryName": "居家"
			}, {
				"categoryCode": 330,
				"categoryName": "母婴"
			}, {
				"categoryCode": 340,
				"categoryName": "食品"
			}, {
				"categoryCode": 350,
				"categoryName": "鞋包配饰"
			}, {
				"categoryCode": 360,
				"categoryName": "数码电器"
			}, {
				"categoryCode": 390,
				"categoryName": "文体户外"
			}],
			"success": true
		},
		"itemData": {
			"items": [{
				"activityId": "159aeeb0646647cb99b84a096e0a3ef8",
				"conditionAmount": 87,
				"couponAmount": 30,
				"handPrice": "58.0",
				"imageUrl": "https://img.alicdn.com/imgextra/i4/2524791965/TB2hRx8mpXXXXX4XXXXXXXXXXXX_!!2524791965.jpg",
				"itemId": "520570174636",
				"originalPrice": "88.0",
				"skipUrl": "",
				"title": "志高手持挂烫机",
				"useDesc": ""
			}, {
				"activityId": "cd25f534c83d4a26a482e9b607caf70f",
				"conditionAmount": 39,
				"couponAmount": 20,
				"handPrice": "19.9",
				"imageUrl": "https://img.alicdn.com/tfscom/i4/T1Aq58FJdeXXXXXXXX_!!0-item_pic.jpg",
				"itemId": "38196435164",
				"originalPrice": "39.9",
				"skipUrl": "",
				"title": "夏季透气网鞋一脚蹬平底单鞋",
				"useDesc": ""
			}, {
				"activityId": "4dd7913101af4195a8fe3a8cd4faa12c",
				"conditionAmount": 198,
				"couponAmount": 80,
				"handPrice": "118.0",
				"imageUrl": "https://img.alicdn.com/tfscom/i1/TB1ePHUQVXXXXaeXFXXXXXXXXXX_!!0-item_pic.jpg",
				"itemId": "548455981544",
				"originalPrice": "198.0",
				"skipUrl": "",
				"title": "顺庭 st-305榨汁机",
				"useDesc": ""
			}, {
				"activityId": "fa613873d01443d1b588fcec4b7d8156",
				"conditionAmount": 29,
				"couponAmount": 10,
				"handPrice": "19.9",
				"imageUrl": "https://img.alicdn.com/tfscom/i1/TB1M8NxRXXXXXc4XVXXXXXXXXXX_!!0-item_pic.jpg",
				"itemId": "549052527120",
				"originalPrice": "29.9",
				"skipUrl": "",
				"title": "夏季纯棉短袖T恤",
				"useDesc": ""
			}, {
				"activityId": "bb74e6c7b5554d8ca95b7cee9b871caf",
				"conditionAmount": 29,
				"couponAmount": 15,
				"handPrice": "14.9",
				"imageUrl": "https://img.alicdn.com/tfscom/i2/TB1lElTQXXXXXa0XVXXXXXXXXXX_!!0-item_pic.jpg",
				"itemId": "546089648528",
				"originalPrice": "29.9",
				"skipUrl": "",
				"title": "醉雨轩舌尖帮系类香脖脖鸡脖散装",
				"useDesc": ""
			}, {
				"activityId": "a0cdfcb19efc464a900364cb2bab8b32",
				"conditionAmount": 129,
				"couponAmount": 30,
				"handPrice": "99.0",
				"imageUrl": "https://img.alicdn.com/tfscom/i2/771598701/TB2p_8PnYXlpuFjSszfXXcSGXXa_!!771598701.jpg",
				"itemId": "540845591559",
				"originalPrice": "129.0",
				"skipUrl": "",
				"title": "韩版双肩包",
				"useDesc": ""
			}, {
				"activityId": "76dee0b55f2242988b98e0c81b495d27",
				"conditionAmount": 88,
				"couponAmount": 40,
				"handPrice": "48.0",
				"imageUrl": "https://img.alicdn.com/tfscom/i3/TB1bSqnRpXXXXbZXpXXXXXXXXXX_!!0-item_pic.jpg",
				"itemId": "548623600034",
				"originalPrice": "88.0",
				"skipUrl": "",
				"title": "中年妈妈套装两件套",
				"useDesc": ""
			}, {
				"activityId": "5d86f9b98c3a48bbb7a4a0138567852f",
				"conditionAmount": 89,
				"couponAmount": 30,
				"handPrice": "59.0",
				"imageUrl": "https://img.alicdn.com/imgextra/i2/2222599681/TB206HhcXXXXXXZXpXXXXXXXXXX_!!2222599681.jpg",
				"itemId": "44105432733",
				"originalPrice": "89.0",
				"skipUrl": "",
				"title": "春夏女凉鞋",
				"useDesc": ""
			}, {
				"activityId": "740edf4b09674f0fb7b839294ea7e054",
				"conditionAmount": 198,
				"couponAmount": 100,
				"handPrice": "98.0",
				"imageUrl": "https://img.alicdn.com/tfscom/i1/TB1f9zvQpXXXXXLaXXXXXXXXXXX_!!0-item_pic.jpg",
				"itemId": "528355629604",
				"originalPrice": "198.0",
				"skipUrl": "",
				"title": "金稻蒸脸器纳米喷雾补水仪",
				"useDesc": ""
			}, {
				"activityId": "70a24b63b53b4b9fa9f421dadfcad06a",
				"conditionAmount": 209,
				"couponAmount": 80,
				"handPrice": "129.0",
				"imageUrl": "https://img.alicdn.com/tfscom/i2/TB1Ey8yRpXXXXakaXXXXXXXXXXX_!!0-item_pic.jpg",
				"itemId": "549616371049",
				"originalPrice": "209.0",
				"skipUrl": "",
				"title": "进口400粒胶原蛋白肽粉胶囊",
				"useDesc": ""
			}],
			"pageNo": 1,
			"success": true,
			"totalPage": 232
		}
	};
}

var PageObj = function() {
	this.pageNo = [];
	this.isFetching = [];
	this.isLastPage = [];
	// 当前所在类目，默认选中第一个
	this.activeIndex = parseInt(cacheObj.getItem('index_category')) || 0;
	this.categoryID = [];
	// 一些常用变量
	this.$nav = null;
	this.$goTop = $('#JS_goTop');
	this.$loadStatus = null;
	this.isSurportSticky = false;
	this.navOffsetTop = null;
	this.screenHeight = $(window).height();
	this.preLoadHeight = 400 * window.dpr;
};
// 页面初始化
PageObj.prototype.init = function() {
	var self = this;
	// 初始化页面
	self.initPage();
	// 加载数据
	self.fetchItemList();
	// 初始化插件
	self.initPlugins();
	// 绑定页面事件
	self.bindEvent();
};
// 初始化页面
PageObj.prototype.initPage = function() {
	var self = this,
		configData = pageData.configData,
		blockData = configData.block,
		$container = $("#container"),
		$bannerDom = null,
		$iconDom = null,
		$blockDom = null,
		$navDom = null;

	try {
		$bannerDom = $(template("bannerContainer", configData));
		$container.find("#topBanner").append($bannerDom);

		// 功能区块
		$iconDom = $(template("iconContainer", configData));
		$container.find("#iconWrap").append($iconDom);

		// block区域
		blockData.forEach(function(blockObj) {
			if (blockObj.data && blockObj.data.length > 0) {
				$blockDom = $(template(blockObj.type + "Container", blockObj));
				$container.append($blockDom);
			}
		});

		$navDom = $(template("navContainer", configData));
		$container.append($navDom);

		// 全部类目下，首屏数据从变量中获取
		if (self.activeIndex === 0) {
			self.parseData(pageData.itemData, self.activeIndex);
		}
	} catch (err) {
		alert("页面初始化失败" + err);
	}
	// 获取类目id，初始化各类目页码
	configData.category.forEach(function(item) {
		self.categoryID.push(item.categoryCode);
		self.pageNo.push(0);
	});
	// 全部类目首屏数据从变量中获取
	self.pageNo[0] = 1;

	// 保存常用对象的引用
	self.$nav = $('#navList');
	self.isSurportSticky = $('#navContain').css("position").indexOf("sticky") > -1 ? true : false;
	self.navOffsetTop = $('#navContain').offset().top;
	self.$loadStatus = $('.loadStatus');
};
// 初始化插件
PageObj.prototype.initPlugins = function() {
	var self = this;
	// swiper插件
	var navSwiper = new Swiper('#navList', {
		freeMode: true,
		slidesPerView: 'auto',
		onInit: function(swiper) {
			$(swiper.slides[self.activeIndex]).addClass('on');
			swiper.slideTo(self.activeIndex, 80);
		},
		onTap: function(swiper, event) {
			itemSwiper.slideTo(swiper.clickedIndex, 80);
		}
	});

	var itemSwiper = new Swiper('#itemList', {
		observer: true,
		observeParents: true,
		onInit: function(swiper) {
			swiper.slideTo(self.activeIndex, 80);
		},
		onSlideChangeStart: function(swiper) {
			self.activeIndex = swiper.activeIndex;

			var anchor = self.getCacheAnchor();
			if (anchor >= self.navOffsetTop) {
				$('html,body').scrollTop(self.navOffsetTop + window.dpr);
			}
			if (!$('.itemsWrap').eq(self.activeIndex).html() && !self.isFetching[self.activeIndex]) {
				self.fetchItemList();
			}
		},
		onSlideChangeEnd: function(swiper) {
			var activeIndex = swiper.activeIndex;

			navSwiper.slides.removeClass('on');
			$(navSwiper.slides[activeIndex]).addClass('on');

			navSwiper.slideTo(activeIndex < 2 ? 0 : activeIndex - 2, 80);

			cacheObj.setItem('index_category', activeIndex);
		}
	});

	var bannerSwiper = new Swiper('#topBanner', {
		autoplay: 1000,
		loop: false,
		pagination: '.swiper-pagination',
		preloadImages: false,
		lazyLoading: true
	});
};
//获取商品列表
PageObj.prototype.fetchItemList = function() {
	var self = this,
		activeIndex = self.activeIndex;

	self.isFetching[activeIndex] = true;

	cacheObj.ajaxData({
		url: "//c.taofen8.com/cps/getItems",
		data: {
			"categoryID": self.categoryID[activeIndex],
			"pageNo": (self.pageNo[activeIndex] || 0) + 1
		},
		key: 'index_items_' + activeIndex,
		success: function(data) {
			if (data.success) {
				try {
					self.parseData(data, activeIndex);
					self.pageNo[activeIndex] = parseInt(data.pageNo);
				} catch (err) {
					alert("解析数据失败" + err);
				}
				if (self.pageNo[activeIndex] === data.totalPage || data.totalPage === 0) {
					self.isLastPage[activeIndex] = true;
					self.$loadStatus.eq(activeIndex).html('已经到底了哦');
				} else {
					// self.$loadStatus.eq(activeIndex).html('加载完成').hide();
				}
			} else {
				self.$loadStatus.eq(activeIndex).html('数据出错，再试一次吧');
			}

			self.isFetching[activeIndex] = false;
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			self.$loadStatus.eq(activeIndex).html('网络不给力，再试一次吧');
			self.isFetching[activeIndex] = false;
		},
		extendCache: function(cacheData, newData) {
			//本地缓存数据拼接回调
			var itemLen = (newData.items && newData.items.length) || 0;

			if (!newData.success || itemLen === 0) return null;

			if (cacheData == null) {
				cacheData = newData;
			} else if (cacheData.pageNo !== newData.pageNo) {
				cacheData.pageNo = newData.pageNo;
				$.merge(cacheData.items, newData.items);
			}

			return cacheData;
		},
		isFromCache: function(cacheData) {
			//本地缓存检查回调
			return self.pageNo[activeIndex] < cacheData.pageNo;
		},
		complete: function() {
			// 本地数据加载完成回调
			var anchor = self.getCacheAnchor();

			if (anchor) {
				$("html,body").animate({
					scrollTop: anchor
				}, 0);
			}
		}
	});
};
//解析商品列表
PageObj.prototype.parseData = function(data, activeIndex) {
	var self = this;
	var $items = $(template("itemContainer", data));
	var $itemsWrap = $(".itemsWrap").eq(activeIndex);

	if (process.env.NODE_ENV === "development") {
		console.log("parseData->activeIndex=" + activeIndex)
	}

	$itemsWrap.append($items);

	// 图片懒加载
	$items.find("img.lazyload").lazyload({
		effect: "fadeIn",
		effectspeed: 1000,
		threshold: 200,
		event: "scrollstop"
	});
};
// 绑定页面事件
PageObj.prototype.bindEvent = function() {
	var self = this;
	// 页面滚动
	$(window).on('scroll', $.proxy(self.scrollWindow, self));
	// 返回顶部
	$("#JS_goTop").on('click', self.goTop);
	// 处理轮播图，模块区域的跳转
	$("#topBanner, .block").on('click', 'img', $.proxy(self.handleJump, self));
	// 点击商品
	$("#itemList").on('click', '.itemsWrap li', $.proxy(self.viewDetail, self));
};
// 监听滚动事件
PageObj.prototype.scrollWindow = function(e) {
	var self = this;
	var docScrollTop = $(document).scrollTop();
	// 触发加载数据的位置
	var loadPoint = self.$loadStatus.eq(self.activeIndex).offset().top - self.screenHeight - self.preLoadHeight;

	if (docScrollTop >= self.navOffsetTop) {
		if (!self.isSurportSticky) {
			self.$nav.css({
				'position': 'fixed'
			});
		}
		self.$goTop.fadeIn();
	} else {
		if (!self.isSurportSticky) {
			self.$nav.css({
				'position': 'static'
			});
		}
		self.$goTop.fadeOut();
	}
	// 保存页面当前位置
	self.saveCacheAnchor();
	// 滚动到页面底部时加载数据
	if (docScrollTop > loadPoint && !self.isLastPage[self.activeIndex] && !self.isFetching[self.activeIndex]) {
		if (process.env.NODE_ENV === 'development') {
			console.log('scrollWindow->activeIndex=' + self.activeIndex);
		}
		self.$loadStatus.eq(self.activeIndex).html('正在加载中...');
		self.fetchItemList();
	}
};
// 返回顶部
PageObj.prototype.goTop = function(e) {
	$('html,body').scrollTop(0);
};
// 处理轮播图，模块区域的跳转
PageObj.prototype.handleJump = function(e) {
	var self = this,
		url = $(e.target).data('url');

	if (!url) {
		return;
	} else {
		window.location.href = url;
	}
};
// 点击商品列表
PageObj.prototype.viewDetail = function(e) {
	var itemId = $(e.target).closest('li').data('itemid'),
		activityId = $(e.target).closest('li').data('activityid');

	window.location.href = "//c.taofen8.com/cps/couponItem/" + itemId + "/" + activityId;
};
//保存当前锚点
PageObj.prototype.saveCacheAnchor = function() {
	cacheObj.setItem("index_anchor", $(window).scrollTop());
};
//获取当前锚点
PageObj.prototype.getCacheAnchor = function() {
	return cacheObj.getItem("index_anchor");
};*/